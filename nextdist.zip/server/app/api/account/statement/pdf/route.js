"use strict";(()=>{var a={};a.id=842,a.ids=[842],a.modules={261:a=>{a.exports=require("next/dist/shared/lib/router/utils/app-paths")},1932:a=>{a.exports=require("url")},3295:a=>{a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:a=>{a.exports=require("querystring")},12412:a=>{a.exports=require("assert")},26666:(a,b,c)=>{c.r(b),c.d(b,{handler:()=>F,patchFetch:()=>E,routeModule:()=>A,serverHooks:()=>D,workAsyncStorage:()=>B,workUnitAsyncStorage:()=>C});var d={};c.r(d),c.d(d,{GET:()=>z});var e=c(19225),f=c(84006),g=c(8317),h=c(99373),i=c(34775),j=c(24235),k=c(261),l=c(54365),m=c(90771),n=c(73461),o=c(67798),p=c(92280),q=c(62018),r=c(45696),s=c(47929),t=c(86439),u=c(37527),v=c(23211),w=c(50172),x=c(20424),y=c(39791);async function z(){let a=await (0,w.getServerSession)(x.N);if(!a?.user)return v.NextResponse.json({error:"Unauthorized"},{status:401});try{let b=await (0,y.EH)(a.user.uid,a.user.password),c=b?.partner_id?.[0],d=await (0,y.$C)(a.user.uid,a.user.password,c),e=await (0,y.NP)(a.user.uid,a.user.password,c),f=d?.name||a.user.email||"Customer",g=new Date,h=e.reduce((a,b)=>a+(b.amount_total||0),0),i=e.reduce((a,b)=>a+((b.amount_total||0)-(b.amount_residual||0)),0),j=e.reduce((a,b)=>a+(b.amount_residual||0),0),k=e.map(a=>{let b="paid"!==a.payment_state&&a.invoice_date_due&&new Date(a.invoice_date_due)<g,c="paid"===a.payment_state?"Paid":"partial"===a.payment_state?"Partial":"Unpaid",d="paid"===a.payment_state?"#16a34a":b?"#dc2626":"#d97706";return`
        <tr style="border-bottom:1px solid #f3f4f6;">
          <td style="padding:8px 12px;font-family:monospace;font-weight:600;color:#004475;">${a.name}</td>
          <td style="padding:8px 12px;color:#4b5563;">${a.invoice_date?new Date(a.invoice_date).toLocaleDateString("en-GB"):"—"}</td>
          <td style="padding:8px 12px;color:${b?"#dc2626":"#4b5563"};">${a.invoice_date_due?new Date(a.invoice_date_due).toLocaleDateString("en-GB"):"—"}${b?" ⚠":""}</td>
          <td style="padding:8px 12px;"><span style="background:${d}22;color:${d};padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">${c}</span></td>
          <td style="padding:8px 12px;text-align:right;">\xa3${a.amount_total.toFixed(2)}</td>
          <td style="padding:8px 12px;text-align:right;font-weight:${a.amount_residual>0?"700":"400"};color:${a.amount_residual>0?"#dc2626":"#4b5563"};">${a.amount_residual>0?`\xa3${a.amount_residual.toFixed(2)}`:"—"}</td>
        </tr>`}).join(""),l=`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Account Statement — ${f}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 40px; color: #111; background: #fff; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; }
    .logo { font-size: 28px; font-weight: 900; color: #004475; letter-spacing: -1px; }
    .logo span { color: #f97316; }
    .meta { text-align: right; font-size: 13px; color: #6b7280; }
    h2 { font-size: 20px; margin: 0 0 4px; color: #111; }
    .summary { display: flex; gap: 16px; margin-bottom: 28px; }
    .card { flex: 1; background: #f9fafb; border-radius: 10px; padding: 16px 20px; }
    .card .label { font-size: 11px; color: #9ca3af; margin-bottom: 4px; }
    .card .value { font-size: 22px; font-weight: 700; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead { background: #f3f4f6; }
    th { padding: 10px 12px; text-align: left; font-weight: 600; color: #374151; font-size: 12px; }
    th:last-child, th:nth-last-child(2) { text-align: right; }
    .footer { margin-top: 40px; font-size: 11px; color: #9ca3af; text-align: center; border-top: 1px solid #f3f4f6; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="logo">FT<span>Paints</span></div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">FTPaints Ltd \xb7 sales@ftpaints.co.uk</div>
    </div>
    <div class="meta">
      <h2>Account Statement</h2>
      <div>${f}</div>
      <div>Generated: ${g.toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"})}</div>
    </div>
  </div>

  <div class="summary">
    <div class="card">
      <div class="label">Total Invoiced</div>
      <div class="value" style="color:#004475;">\xa3${h.toFixed(2)}</div>
    </div>
    <div class="card">
      <div class="label">Total Paid</div>
      <div class="value" style="color:#16a34a;">\xa3${i.toFixed(2)}</div>
    </div>
    <div class="card" style="background:${j>0?"#fff7ed":"#f0fdf4"};">
      <div class="label">Balance Outstanding</div>
      <div class="value" style="color:${j>0?"#d97706":"#16a34a"};">\xa3${j.toFixed(2)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Invoice</th>
        <th>Date</th>
        <th>Due Date</th>
        <th>Status</th>
        <th style="text-align:right;">Total</th>
        <th style="text-align:right;">Outstanding</th>
      </tr>
    </thead>
    <tbody>${k}</tbody>
  </table>

  <div class="footer">
    FTPaints Ltd \xb7 All prices exclusive of VAT \xb7 30-day account terms \xb7 Registered in England &amp; Wales
  </div>
</body>
</html>`;return new v.NextResponse(l,{status:200,headers:{"Content-Type":"text/html; charset=utf-8","Content-Disposition":`inline; filename="statement-${g.toISOString().slice(0,10)}.html"`}})}catch(a){return console.error("Statement PDF error:",a),v.NextResponse.json({error:"Failed to generate statement"},{status:500})}}let A=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/account/statement/pdf/route",pathname:"/api/account/statement/pdf",filename:"route",bundlePath:"app/api/account/statement/pdf/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/fabs/.openclaw/workspace/ftpaints-shop/shop-full/app/api/account/statement/pdf/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:B,workUnitAsyncStorage:C,serverHooks:D}=A;function E(){return(0,g.patchFetch)({workAsyncStorage:B,workUnitAsyncStorage:C})}async function F(a,b,c){c.requestMeta&&(0,h.setRequestMeta)(a,c.requestMeta),A.isDev&&(0,h.addRequestMeta)(a,"devRequestTimingInternalsEnd",process.hrtime.bigint());let d="/api/account/statement/pdf/route";"/index"===d&&(d="/");let e=await A.prepare(a,b,{srcPage:d,multiZoneDraftMode:!1});if(!e)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:g,params:v,nextConfig:w,parsedUrl:x,isDraftMode:y,prerenderManifest:z,routerServerContext:B,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,resolvedPathname:E,clientReferenceManifest:F,serverActionsManifest:G}=e,H=(0,k.normalizeAppPath)(d),I=!!(z.dynamicRoutes[H]||z.routes[E]),J=async()=>((null==B?void 0:B.render404)?await B.render404(a,b,x,!1):b.end("This page could not be found"),null);if(I&&!y){let a=!!z.routes[E],b=z.dynamicRoutes[H];if(b&&!1===b.fallback&&!a){if(w.adapterPath)return await J();throw new t.NoFallbackError}}let K=null;!I||A.isDev||y||(K="/index"===(K=E)?"/":K);let L=!0===A.isDev||!I,M=I&&!L;G&&F&&(0,j.setManifestsSingleton)({page:d,clientReferenceManifest:F,serverActionsManifest:G});let N=a.method||"GET",O=(0,i.getTracer)(),P=O.getActiveScopeSpan(),Q=!!(null==B?void 0:B.isWrappedByNextServer),R=!!(0,h.getRequestMeta)(a,"minimalMode"),S=(0,h.getRequestMeta)(a,"incrementalCache")||await A.getIncrementalCache(a,w,z,R);null==S||S.resetRequestCache(),globalThis.__incrementalCache=S;let T={params:v,previewProps:z.preview,renderOpts:{experimental:{authInterrupts:!!w.experimental.authInterrupts},cacheComponents:!!w.cacheComponents,supportsDynamicResponse:L,incrementalCache:S,cacheLifeProfiles:w.cacheLife,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d,e)=>A.onRequestError(a,b,d,e,B)},sharedContext:{buildId:g}},U=new l.NodeNextRequest(a),V=new l.NodeNextResponse(b),W=m.NextRequestAdapter.fromNodeNextRequest(U,(0,m.signalFromNodeResponse)(b));try{let e,g=async a=>A.handle(W,T).finally(()=>{if(!a)return;a.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let c=O.getRootSpanAttributes();if(!c)return;if(c.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${c.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let f=c.get("next.route");if(f){let b=`${N} ${f}`;a.setAttributes({"next.route":f,"http.route":f,"next.span_name":b}),a.updateName(b),e&&e!==a&&(e.setAttribute("http.route",f),e.updateName(b))}else a.updateName(`${N} ${d}`)}),h=async e=>{var h,i;let j=async({previousCacheEntry:f})=>{try{if(!R&&C&&D&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let d=await g(e);a.fetchMetrics=T.renderOpts.fetchMetrics;let h=T.renderOpts.pendingWaitUntil;h&&c.waitUntil&&(c.waitUntil(h),h=void 0);let i=T.renderOpts.collectedTags;if(!I)return await (0,p.I)(U,V,d,T.renderOpts.pendingWaitUntil),null;{let a=await d.blob(),b=(0,q.toNodeOutgoingHttpHeaders)(d.headers);i&&(b[s.NEXT_CACHE_TAGS_HEADER]=i),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==T.renderOpts.collectedRevalidate&&!(T.renderOpts.collectedRevalidate>=s.INFINITE_CACHE)&&T.renderOpts.collectedRevalidate,e=void 0===T.renderOpts.collectedExpire||T.renderOpts.collectedExpire>=s.INFINITE_CACHE?void 0:T.renderOpts.collectedExpire;return{value:{kind:u.CachedRouteKind.APP_ROUTE,status:d.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:e}}}}catch(b){throw(null==f?void 0:f.isStale)&&await A.onRequestError(a,b,{routerKind:"App Router",routePath:d,routeType:"route",revalidateReason:(0,o.c)({isStaticGeneration:M,isOnDemandRevalidate:C})},!1,B),b}},k=await A.handleResponse({req:a,nextConfig:w,cacheKey:K,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,responseGenerator:j,waitUntil:c.waitUntil,isMinimalMode:R});if(!I)return null;if((null==k||null==(h=k.value)?void 0:h.kind)!==u.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==k||null==(i=k.value)?void 0:i.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});R||b.setHeader("x-nextjs-cache",C?"REVALIDATED":k.isMiss?"MISS":k.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let l=(0,q.fromNodeOutgoingHttpHeaders)(k.value.headers);return R&&I||l.delete(s.NEXT_CACHE_TAGS_HEADER),!k.cacheControl||b.getHeader("Cache-Control")||l.get("Cache-Control")||l.set("Cache-Control",(0,r.getCacheControlHeader)(k.cacheControl)),await (0,p.I)(U,V,new Response(k.value.body,{headers:l,status:k.value.status||200})),null};Q&&P?await h(P):(e=O.getActiveScopeSpan(),await O.withPropagatedContext(a.headers,()=>O.trace(n.BaseServerSpan.handleRequest,{spanName:`${N} ${d}`,kind:i.SpanKind.SERVER,attributes:{"http.method":N,"http.target":a.url}},h),void 0,!Q))}catch(b){if(b instanceof t.NoFallbackError||await A.onRequestError(a,b,{routerKind:"App Router",routePath:H,routeType:"route",revalidateReason:(0,o.c)({isStaticGeneration:M,isOnDemandRevalidate:C})},!1,B),I)throw b;return await (0,p.I)(U,V,new Response(null,{status:500})),null}}},28354:a=>{a.exports=require("util")},29294:a=>{a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:a=>{a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{a.exports=require("crypto")},55591:a=>{a.exports=require("https")},63033:a=>{a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:a=>{a.exports=require("zlib")},79428:a=>{a.exports=require("buffer")},81630:a=>{a.exports=require("http")},86439:a=>{a.exports=require("next/dist/shared/lib/no-fallback-error.external")},94735:a=>{a.exports=require("events")}};var b=require("../../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[445,813,472,300],()=>b(b.s=26666));module.exports=c})();