1:"$Sreact.fragment"
2:I[484,[],"ViewportBoundary"]
3:I[484,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[6869,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"FTPaints Trade Portal"}],["$","meta","1",{"name":"description","content":"Trade ordering portal for FTPaints customers"}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.svg"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?603d046c9a6fdfbb","type":"image/x-icon","sizes":"16x16"}],["$","link","4",{"rel":"icon","href":"/favicon.svg"}],["$","link","5",{"rel":"apple-touch-icon","href":"/favicon.svg"}],["$","$L5","6",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"9kUB06aF9RKaloNuiqRbD"}
