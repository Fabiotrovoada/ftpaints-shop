1:I[7121,[],"LoadingBoundaryProvider"]
2:I[5878,["209","static/chunks/app/loading-faf2cdf2b92b30b1.js"],"default"]
3:"$Sreact.fragment"
4:I[7121,[],""]
5:I[4581,[],""]
6:[]
0:{"rsc":["$","$L1",null,{"loading":[["$","$L2","l",{}],[],[]],"children":["$","$3","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}]}],"isPartial":false,"staleTime":300,"varyParams":"$W6","buildId":"9kUB06aF9RKaloNuiqRbD"}
