1:I[7121,[],"LoadingBoundaryProvider"]
2:I[5878,["209","static/chunks/app/loading-faf2cdf2b92b30b1.js"],"default"]
3:"$Sreact.fragment"
4:I[9520,["882","static/chunks/882-2f1a4a2efae4654f.js","825","static/chunks/825-7bfc1eea02c0795e.js","939","static/chunks/app/layout-86688ea469a05ea6.js"],"SessionProvider"]
5:I[9520,["882","static/chunks/882-2f1a4a2efae4654f.js","825","static/chunks/825-7bfc1eea02c0795e.js","939","static/chunks/app/layout-86688ea469a05ea6.js"],"PayPalProvider"]
6:I[7121,[],""]
7:I[4581,[],""]
8:I[1304,[],"ClientPageRoot"]
9:I[6919,["882","static/chunks/882-2f1a4a2efae4654f.js","974","static/chunks/app/page-c0a2a9cb3e0657fb.js"],"default"]
c:I[484,[],"OutletBoundary"]
d:"$Sreact.suspense"
f:I[484,[],"ViewportBoundary"]
11:I[484,[],"MetadataBoundary"]
13:I[7123,[],"default",1]
:HL["/_next/static/media/e4af272ccee01ff0-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/33e01da99f0b4c38.css","style"]
0:{"P":null,"c":["",""],"q":"","i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",20],[["$","$L1",null,{"loading":[["$","$L2","l",{}],[],[]],"children":["$","$3","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/33e01da99f0b4c38.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"__className_f367f3","children":["$","$L4",null,{"children":["$","$L5",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]}]]}]}],{"children":[["$","$3","c",{"children":[["$","$L8",null,{"Component":"$9","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@a","$@b"]}}],null,["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],{},null,false,null]},null,false,null],["$","$3","h",{"children":[null,["$","$Lf",null,{"children":"$L10"}],["$","div",null,{"hidden":true,"children":["$","$L11",null,{"children":["$","$d",null,{"name":"Next.Metadata","children":"$L12"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],false]],"m":"$undefined","G":["$13",[]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"9kUB06aF9RKaloNuiqRbD"}
a:{}
b:"$0:f:0:1:1:children:0:props:children:0:props:serverProvidedParams:params"
10:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
14:I[6869,[],"IconMark"]
e:null
12:[["$","title","0",{"children":"FTPaints Trade Portal"}],["$","meta","1",{"name":"description","content":"Trade ordering portal for FTPaints customers"}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.svg"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?603d046c9a6fdfbb","type":"image/x-icon","sizes":"16x16"}],["$","link","4",{"rel":"icon","href":"/favicon.svg"}],["$","link","5",{"rel":"apple-touch-icon","href":"/favicon.svg"}],["$","$L14","6",{}]]
