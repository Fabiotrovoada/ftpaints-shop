// Odoo JSON-RPC API client for FTPaints Trade Portal
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const ODOO_URL = process.env.ODOO_URL!;
const ODOO_DB = process.env.ODOO_DB!;

// Admin credentials used for all read operations (products, categories, etc.)
// Portal/trade customers don't have XML-RPC access to internal models
let _adminUid: number | null = null;

async function getAdminUid(): Promise<number> {
  if (_adminUid) return _adminUid;
  const email = process.env.ODOO_ADMIN_EMAIL!;
  const password = process.env.ODOO_ADMIN_PASSWORD!;
  const res = await fetch(`${ODOO_URL}/xmlrpc/2/common`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/xml' },
    body: buildXmlrpc('authenticate', [ODOO_DB, email, password, {}]),
  });
  const uid = parseXml(await res.text());
  if (typeof uid !== 'number' || uid <= 0) throw new Error('Admin auth failed');
  _adminUid = uid;
  return uid;
}

async function callModelAsAdmin(
  model: string,
  method: string,
  args: unknown[],
  kwargs: Record<string, unknown> = {}
): Promise<unknown> {
  const uid = await getAdminUid();
  const password = process.env.ODOO_ADMIN_PASSWORD!;
  return callModel(uid, password, model, method, args, kwargs);
}

let _rpcId = 1;
async function jsonrpcCall(
  endpoint: string,
  method: string,
  params: Record<string, unknown>
): Promise<unknown> {
  const res = await fetch(`${ODOO_URL}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', method: 'call', id: _rpcId++, params }),
  });
  const data = await res.json() as { result?: unknown; error?: { message: string } };
  if (data.error) throw new Error(data.error.message);
  return data.result;
}

async function callModel(
  uid: number,
  password: string,
  model: string,
  method: string,
  args: unknown[],
  kwargs: Record<string, unknown> = {}
): Promise<unknown> {
  const res = await fetch(`${ODOO_URL}/xmlrpc/2/object`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/xml' },
    body: buildXmlrpc('execute_kw', [ODOO_DB, uid, password, model, method, args, kwargs]),
  });
  const text = await res.text();
  return parseXml(text);
}

function buildXmlrpc(method: string, params: unknown[]): string {
  return `<?xml version="1.0"?><methodCall><methodName>${method}</methodName><params>${params.map(p => `<param>${valToXml(p)}</param>`).join('')}</params></methodCall>`;
}

function valToXml(v: unknown): string {
  if (v === null || v === undefined) return '<value><boolean>0</boolean></value>';
  if (typeof v === 'boolean') return `<value><boolean>${v ? 1 : 0}</boolean></value>`;
  if (typeof v === 'number') return Number.isInteger(v) ? `<value><int>${v}</int></value>` : `<value><double>${v}</double></value>`;
  if (typeof v === 'string') return `<value><string>${v.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</string></value>`;
  if (Array.isArray(v)) return `<value><array><data>${v.map(valToXml).join('')}</data></array></value>`;
  if (typeof v === 'object') {
    const m = Object.entries(v as Record<string,unknown>).map(([k,val]) => `<member><name>${k}</name>${valToXml(val)}</member>`).join('');
    return `<value><struct>${m}</struct></value>`;
  }
  return `<value><string>${String(v)}</string></value>`;
}

function parseXml(xml: string): unknown {
  if (xml.includes('<fault>')) throw new Error('Odoo fault: ' + xml.slice(0, 300));
  // Use a simple recursive descent parser
  function parseNode(s: string): [unknown, number] {
    s = s.trim();
    if (s.startsWith('<value>')) {
      const inner = s.slice(7);
      const [val, len] = parseNode(inner);
      return [val, 7 + len + 8]; // <value> + content + </value>
    }
    if (s.startsWith('<int>') || s.startsWith('<i4>')) {
      const tag = s.startsWith('<int>') ? 'int' : 'i4';
      const end = s.indexOf(`</${tag}>`);
      return [parseInt(s.slice(tag.length+2, end)), end + tag.length + 3];
    }
    if (s.startsWith('<double>')) { const e = s.indexOf('</double>'); return [parseFloat(s.slice(8,e)), e+9]; }
    if (s.startsWith('<boolean>')) { const e = s.indexOf('</boolean>'); return [s.slice(9,e)==='1', e+10]; }
    if (s.startsWith('<string>')) { const e = s.indexOf('</string>'); return [s.slice(8,e).replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>'), e+9]; }
    if (s.startsWith('<nil/>')) return [null, 6];
    if (s.startsWith('<array>')) {
      const dataStart = s.indexOf('<data>') + 6;
      const dataEnd = s.indexOf('</data>');
      let items: unknown[] = [], pos = dataStart;
      const inner = s.slice(dataStart, dataEnd);
      let i = 0;
      while (i < inner.length) {
        const trimmed = inner.slice(i).trimStart();
        if (!trimmed.startsWith('<value>')) break;
        const offset = inner.slice(i).indexOf('<value>');
        const [val, len] = parseNode(trimmed);
        items.push(val);
        i += offset + len;
      }
      return [items, dataEnd + 7 + 8]; // </data></array>
    }
    if (s.startsWith('<struct>')) {
      const obj: Record<string,unknown> = {};
      let pos = 8;
      while (true) {
        const rest = s.slice(pos).trimStart();
        if (rest.startsWith('</struct>') || !rest.startsWith('<member>')) break;
        const mEnd = s.indexOf('</member>', pos);
        const member = s.slice(pos, mEnd + 9);
        const nameM = member.match(/<name>(.*?)<\/name>/);
        const valStart = member.indexOf('<value>');
        if (nameM && valStart >= 0) {
          const [val] = parseNode(member.slice(valStart));
          obj[nameM[1]] = val;
        }
        pos = mEnd + 9;
      }
      return [obj, s.indexOf('</struct>') + 9];
    }
    return [s, s.length];
  }
  const paramStart = xml.indexOf('<param>');
  if (paramStart < 0) return null;
  const inner = xml.slice(paramStart + 7, xml.indexOf('</param>'));
  const [result] = parseNode(inner.trim());
  return result;
}

// ─── Auth ────────────────────────────────────────────────────────────────────

export async function authenticate(email: string, password: string): Promise<number | false> {
  try {
    const res = await fetch(`${ODOO_URL}/xmlrpc/2/common`, {
      method: 'POST',
      headers: { 'Content-Type': 'text/xml' },
      body: buildXmlrpc('authenticate', [ODOO_DB, email, password, {}]),
    });
    const uid = parseXml(await res.text());
    return typeof uid === 'number' && uid > 0 ? uid : false;
  } catch {
    return false;
  }
}

// ─── Partner ─────────────────────────────────────────────────────────────────

export async function getPartnerByUid(uid: number, _password: string) {
  // Use admin to read user/partner info — portal users can't read res.users via XML-RPC
  const partners = await callModelAsAdmin('res.users', 'read', [[uid]], {
    fields: ['name', 'email', 'partner_id', 'company_id']
  }) as Record<string, unknown>[];
  return partners[0] || null;
}

export async function getPartnerInfo(_uid: number, _password: string, partnerId: number) {
  const partners = await callModelAsAdmin('res.partner', 'read', [[partnerId]], {
    fields: ['name', 'email', 'phone', 'street', 'city', 'zip', 'country_id', 'credit', 'credit_limit', 'property_payment_term_id']
  }) as Record<string, unknown>[];
  return partners[0] || null;
}

// ─── Products ────────────────────────────────────────────────────────────────

export async function getProducts(
  _uid: number,
  _password: string,
  options: {
    search?: string;
    categoryId?: number;
    brandId?: number;
    inStockOnly?: boolean;
    offset?: number;
    limit?: number;
    sort?: string;
  } = {}
) {
  const domain: unknown[] = [['active', '=', true]];
  if (options.search) domain.push(['name', 'ilike', options.search]);
  if (options.categoryId) domain.push(['categ_id', '=', options.categoryId]);
  if (options.inStockOnly) domain.push(['qty_available', '>', 0]);

  const products = await callModelAsAdmin('product.template', 'search_read', [domain], {
    fields: ['id', 'name', 'default_code', 'list_price', 'standard_price', 'categ_id',
             'qty_available', 'virtual_available', 'description_sale', 'seller_ids',
             'uom_id', 'image_128'],
    limit: options.limit || 25,
    offset: options.offset || 0,
    order: options.sort || 'name asc'
  }) as Record<string, unknown>[];

  const total = await callModelAsAdmin('product.template', 'search_count', [domain]) as number;

  return { products, total };
}

export async function getProductById(_uid: number, _password: string, id: number) {
  const products = await callModelAsAdmin('product.template', 'read', [[id]], {
    fields: ['id', 'name', 'default_code', 'list_price', 'standard_price', 'categ_id',
             'qty_available', 'virtual_available', 'description', 'description_sale',
             'sellers', 'uom_id', 'image_1920', 'product_variant_ids', 'attribute_line_ids']
  }) as Record<string, unknown>[];
  return products[0] || null;
}

export async function getCategories(_uid: number, _password: string) {
  return await callModelAsAdmin('product.category', 'search_read',
    [[]], { fields: ['id', 'name', 'parent_id', 'complete_name'], limit: 300, order: 'complete_name asc' }
  ) as Record<string, unknown>[];
}

// ─── Orders ──────────────────────────────────────────────────────────────────

export async function getSaleOrders(_uid: number, _password: string, partnerId: number) {
  return await callModelAsAdmin('sale.order', 'search_read',
    [[['partner_id', '=', partnerId], ['state', 'in', ['sale', 'done']]]],
    {
      fields: ['id', 'name', 'date_order', 'amount_total', 'state', 'order_line'],
      order: 'date_order desc',
      limit: 50
    }
  ) as Record<string, unknown>[];
}

export async function getSaleOrderLines(_uid: number, _password: string, orderId: number) {
  return await callModelAsAdmin('sale.order.line', 'search_read',
    [[['order_id', '=', orderId]]],
    { fields: ['product_id', 'product_uom_qty', 'price_unit', 'price_subtotal', 'name'] }
  ) as Record<string, unknown>[];
}

export async function createSaleOrder(
  uid: number,
  password: string,
  partnerId: number,
  lines: Array<{ productId: number; qty: number; price: number }>,
  note?: string
) {
  const orderLines = lines.map(l => [0, 0, {
    product_id: l.productId,
    product_uom_qty: l.qty,
    price_unit: l.price,
  }]);

  return await callModel(uid, password, 'sale.order', 'create', [{
    partner_id: partnerId,
    order_line: orderLines,
    note: note || '',
  }]) as number;
}

// ─── Invoices ────────────────────────────────────────────────────────────────

export async function getInvoices(_uid: number, _password: string, partnerId: number) {
  return await callModelAsAdmin('account.move', 'search_read',
    [[['partner_id', '=', partnerId], ['move_type', '=', 'out_invoice'], ['state', '=', 'posted']]],
    {
      fields: ['id', 'name', 'invoice_date', 'invoice_date_due', 'amount_total',
               'amount_residual', 'payment_state', 'state'],
      order: 'invoice_date desc',
      limit: 50
    }
  ) as Record<string, unknown>[];
}

// ─── Generic execute_kw wrapper (JSON-RPC, uid/password unused but kept for compat) ───

// ─── Invoice PDF (via Odoo report endpoint) ──────────────────────────────────

export async function getInvoicePdf(uid: number, password: string, invoiceId: number): Promise<ArrayBuffer> {
  // Odoo serves PDFs via the /report/pdf/ endpoint with cookie-based session
  // We use the JSON-RPC report.render_qweb_pdf method instead
  const result = await jsonrpcCall('web/dataset/call_kw', 'render_qweb_pdf', {
    model: 'account.move',
    method: 'render_qweb_pdf',
    args: [invoiceId],
    kwargs: {
      report_ref: 'account.report_invoice',
    },
  }) as { result?: string; error?: { message: string } };

  // Fallback: use /report/pdf/ endpoint with admin credentials
  const reportUrl = `${ODOO_URL}/report/pdf/account.report_invoice/${invoiceId}`;
  const sessionRes = await fetch(`${ODOO_URL}/web/session/authenticate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      method: 'call',
      id: 1,
      params: {
        db: ODOO_DB,
        login: process.env.ODOO_ADMIN_EMAIL || 'fabio@ftpaints.co.uk',
        password: process.env.ODOO_ADMIN_PASSWORD || password,
      },
    }),
  });

  const cookies = sessionRes.headers.get('set-cookie') || '';
  const sessionData = await sessionRes.json() as { result?: { session_id?: string } };
  const sessionId = sessionData?.result?.session_id;

  const pdfRes = await fetch(reportUrl, {
    headers: {
      Cookie: cookies,
      ...(sessionId ? { 'X-Openerp-Session-Id': sessionId } : {}),
    },
  });

  if (!pdfRes.ok) {
    throw new Error(`Odoo report returned ${pdfRes.status}`);
  }

  return pdfRes.arrayBuffer();
}
