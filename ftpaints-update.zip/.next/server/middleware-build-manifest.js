globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/lDBW_BmKzerd8mP33wmBX/_buildManifest.js",
    "static/lDBW_BmKzerd8mP33wmBX/_ssgManifest.js",
    "static/lDBW_BmKzerd8mP33wmBX/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0bzupvr5gt3k9.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0e-wrhqh4h3r5.js",
    "static/chunks/16g.ca89g7fib.js",
    "static/chunks/turbopack-01k4tcbswpwkd.js"
  ]
};
