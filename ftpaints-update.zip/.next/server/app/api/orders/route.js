var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[root-of-the-server]__0gel5pv._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_0qla9fh.js")
R.m(81585)
module.exports=R.m(81585).exports
