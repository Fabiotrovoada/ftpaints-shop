var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/statement/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__0swk7a6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/_next-internal_server_app_api_account_statement_pdf_route_actions_0ireupc.js")
R.m(31501)
module.exports=R.m(31501).exports
