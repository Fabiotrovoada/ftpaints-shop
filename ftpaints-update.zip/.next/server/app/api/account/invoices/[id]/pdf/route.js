var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/invoices/[id]/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__0f_mxil._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/_next-internal_server_app_api_account_invoices_[id]_pdf_route_actions_0-01xgn.js")
R.m(50313)
module.exports=R.m(50313).exports
