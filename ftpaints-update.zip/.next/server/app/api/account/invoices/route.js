var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/invoices/route.js")
R.c("server/chunks/[root-of-the-server]__0t46a7h._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_account_invoices_route_actions_0y9a114.js")
R.m(98476)
module.exports=R.m(98476).exports
