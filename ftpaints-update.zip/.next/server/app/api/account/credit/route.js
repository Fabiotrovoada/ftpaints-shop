var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/credit/route.js")
R.c("server/chunks/[root-of-the-server]__004gj33._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_account_credit_route_actions_0_t~nub.js")
R.m(73368)
module.exports=R.m(73368).exports
