var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/orders/route.js")
R.c("server/chunks/[root-of-the-server]__0~sazrk._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0ph4ncw._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_account_orders_route_actions_129_i0b.js")
R.m(7064)
module.exports=R.m(7064).exports
