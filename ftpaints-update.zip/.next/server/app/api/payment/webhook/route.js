var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0mukqrw._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_webhook_route_actions_0.oe6c-.js")
R.m(63915)
module.exports=R.m(63915).exports
