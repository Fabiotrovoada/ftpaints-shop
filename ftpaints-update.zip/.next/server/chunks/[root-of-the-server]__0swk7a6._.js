module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},21517,(e,t,a)=>{t.exports=e.x("http",()=>require("http"))},54799,(e,t,a)=>{t.exports=e.x("crypto",()=>require("crypto"))},24836,(e,t,a)=>{t.exports=e.x("https",()=>require("https"))},27699,(e,t,a)=>{t.exports=e.x("events",()=>require("events"))},31501,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),n=e.i(59756),i=e.i(61916),o=e.i(74677),s=e.i(69741),d=e.i(16795),l=e.i(87718),p=e.i(95169),u=e.i(47587),c=e.i(66012),x=e.i(70101),h=e.i(26937),v=e.i(10372),g=e.i(93695);e.i(52474);var f=e.i(220),m=e.i(89171),y=e.i(57660),b=e.i(68105),w=e.i(29769);async function R(){let e=await (0,y.getServerSession)(b.authOptions);if(!e?.user)return m.NextResponse.json({error:"Unauthorized"},{status:401});try{let t=await (0,w.getPartnerByUid)(e.user.uid,e.user.password),a=t?.partner_id?.[0],r=await (0,w.getPartnerInfo)(e.user.uid,e.user.password,a),n=await (0,w.getInvoices)(e.user.uid,e.user.password,a),i=r?.name||e.user.email||"Customer",o=new Date,s=n.reduce((e,t)=>e+(t.amount_total||0),0),d=n.reduce((e,t)=>e+((t.amount_total||0)-(t.amount_residual||0)),0),l=n.reduce((e,t)=>e+(t.amount_residual||0),0),p=n.map(e=>{let t="paid"!==e.payment_state&&e.invoice_date_due&&new Date(e.invoice_date_due)<o,a="paid"===e.payment_state?"Paid":"partial"===e.payment_state?"Partial":"Unpaid",r="paid"===e.payment_state?"#16a34a":t?"#dc2626":"#d97706";return`
        <tr style="border-bottom:1px solid #f3f4f6;">
          <td style="padding:8px 12px;font-family:monospace;font-weight:600;color:#004475;">${e.name}</td>
          <td style="padding:8px 12px;color:#4b5563;">${e.invoice_date?new Date(e.invoice_date).toLocaleDateString("en-GB"):"—"}</td>
          <td style="padding:8px 12px;color:${t?"#dc2626":"#4b5563"};">${e.invoice_date_due?new Date(e.invoice_date_due).toLocaleDateString("en-GB"):"—"}${t?" ⚠":""}</td>
          <td style="padding:8px 12px;"><span style="background:${r}22;color:${r};padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">${a}</span></td>
          <td style="padding:8px 12px;text-align:right;">\xa3${e.amount_total.toFixed(2)}</td>
          <td style="padding:8px 12px;text-align:right;font-weight:${e.amount_residual>0?"700":"400"};color:${e.amount_residual>0?"#dc2626":"#4b5563"};">${e.amount_residual>0?`\xa3${e.amount_residual.toFixed(2)}`:"—"}</td>
        </tr>`}).join(""),u=`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Account Statement — ${i}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 40px; color: #111; background: #fff; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; }
    .logo { font-size: 28px; font-weight: 900; color: #004475; letter-spacing: -1px; }
    .logo span { color: #f97316; }
    .meta { text-align: right; font-size: 13px; color: #6b7280; }
    h2 { font-size: 20px; margin: 0 0 4px; color: #111; }
    .summary { display: flex; gap: 16px; margin-bottom: 28px; }
    .card { flex: 1; background: #f9fafb; border-radius: 10px; padding: 16px 20px; }
    .card .label { font-size: 11px; color: #9ca3af; margin-bottom: 4px; }
    .card .value { font-size: 22px; font-weight: 700; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead { background: #f3f4f6; }
    th { padding: 10px 12px; text-align: left; font-weight: 600; color: #374151; font-size: 12px; }
    th:last-child, th:nth-last-child(2) { text-align: right; }
    .footer { margin-top: 40px; font-size: 11px; color: #9ca3af; text-align: center; border-top: 1px solid #f3f4f6; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="logo">FT<span>Paints</span></div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">FTPaints Ltd \xb7 sales@ftpaints.co.uk</div>
    </div>
    <div class="meta">
      <h2>Account Statement</h2>
      <div>${i}</div>
      <div>Generated: ${o.toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"})}</div>
    </div>
  </div>

  <div class="summary">
    <div class="card">
      <div class="label">Total Invoiced</div>
      <div class="value" style="color:#004475;">\xa3${s.toFixed(2)}</div>
    </div>
    <div class="card">
      <div class="label">Total Paid</div>
      <div class="value" style="color:#16a34a;">\xa3${d.toFixed(2)}</div>
    </div>
    <div class="card" style="background:${l>0?"#fff7ed":"#f0fdf4"};">
      <div class="label">Balance Outstanding</div>
      <div class="value" style="color:${l>0?"#d97706":"#16a34a"};">\xa3${l.toFixed(2)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Invoice</th>
        <th>Date</th>
        <th>Due Date</th>
        <th>Status</th>
        <th style="text-align:right;">Total</th>
        <th style="text-align:right;">Outstanding</th>
      </tr>
    </thead>
    <tbody>${p}</tbody>
  </table>

  <div class="footer">
    FTPaints Ltd \xb7 All prices exclusive of VAT \xb7 30-day account terms \xb7 Registered in England &amp; Wales
  </div>
</body>
</html>`;return new m.NextResponse(u,{status:200,headers:{"Content-Type":"text/html; charset=utf-8","Content-Disposition":`inline; filename="statement-${o.toISOString().slice(0,10)}.html"`}})}catch(e){return console.error("Statement PDF error:",e),m.NextResponse.json({error:"Failed to generate statement"},{status:500})}}e.s(["GET",0,R],78618);var _=e.i(78618);let E=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/account/statement/pdf/route",pathname:"/api/account/statement/pdf",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/account/statement/pdf/route.ts",nextConfigOutput:"",userland:_}),{workAsyncStorage:C,workUnitAsyncStorage:A,serverHooks:T}=E;async function P(e,t,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),E.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let m="/api/account/statement/pdf/route";m=m.replace(/\/index$/,"")||"/";let y=await E.prepare(e,t,{srcPage:m,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:b,params:w,nextConfig:R,parsedUrl:_,isDraftMode:C,prerenderManifest:A,routerServerContext:T,isOnDemandRevalidate:P,revalidateOnlyGenerated:S,resolvedPathname:$,clientReferenceManifest:q,serverActionsManifest:N}=y,k=(0,s.normalizeAppPath)(m),D=!!(A.dynamicRoutes[k]||A.routes[$]),O=async()=>((null==T?void 0:T.render404)?await T.render404(e,t,_,!1):t.end("This page could not be found"),null);if(D&&!C){let e=!!A.routes[$],t=A.dynamicRoutes[k];if(t&&!1===t.fallback&&!e){if(R.adapterPath)return await O();throw new g.NoFallbackError}}let j=null;!D||E.isDev||C||(j="/index"===(j=$)?"/":j);let I=!0===E.isDev||!D,U=D&&!I;N&&q&&(0,o.setManifestsSingleton)({page:m,clientReferenceManifest:q,serverActionsManifest:N});let F=e.method||"GET",H=(0,i.getTracer)(),M=H.getActiveScopeSpan(),z=!!(null==T?void 0:T.isWrappedByNextServer),B=!!(0,n.getRequestMeta)(e,"minimalMode"),L=(0,n.getRequestMeta)(e,"incrementalCache")||await E.getIncrementalCache(e,R,A,B);null==L||L.resetRequestCache(),globalThis.__incrementalCache=L;let G={params:w,previewProps:A.preview,renderOpts:{experimental:{authInterrupts:!!R.experimental.authInterrupts},cacheComponents:!!R.cacheComponents,supportsDynamicResponse:I,incrementalCache:L,cacheLifeProfiles:R.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,n)=>E.onRequestError(e,t,r,n,T)},sharedContext:{buildId:b}},K=new d.NodeNextRequest(e),V=new d.NodeNextResponse(t),W=l.NextRequestAdapter.fromNodeNextRequest(K,(0,l.signalFromNodeResponse)(t));try{let n,o=async e=>E.handle(W,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=H.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${F} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",r),n.updateName(t))}else e.updateName(`${F} ${m}`)}),s=async n=>{var i,s;let d=async({previousCacheEntry:a})=>{try{if(!B&&P&&S&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await o(n);e.fetchMetrics=G.renderOpts.fetchMetrics;let s=G.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let d=G.renderOpts.collectedTags;if(!D)return await (0,c.sendResponse)(K,V,i,G.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,x.toNodeOutgoingHttpHeaders)(i.headers);d&&(t[v.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=v.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,r=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=v.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:P})},!1,T),t}},l=await E.handleResponse({req:e,nextConfig:R,cacheKey:j,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:P,revalidateOnlyGenerated:S,responseGenerator:d,waitUntil:r.waitUntil,isMinimalMode:B});if(!D)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(s=l.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",P?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,x.fromNodeOutgoingHttpHeaders)(l.value.headers);return B&&D||p.delete(v.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,h.getCacheControlHeader)(l.cacheControl)),await (0,c.sendResponse)(K,V,new Response(l.value.body,{headers:p,status:l.value.status||200})),null};z&&M?await s(M):(n=H.getActiveScopeSpan(),await H.withPropagatedContext(e.headers,()=>H.trace(p.BaseServerSpan.handleRequest,{spanName:`${F} ${m}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},s),void 0,!z))}catch(t){if(t instanceof g.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:k,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:P})},!1,T),D)throw t;return await (0,c.sendResponse)(K,V,new Response(null,{status:500})),null}}e.s(["handler",0,P,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:A})},"routeModule",0,E,"serverHooks",0,T,"workAsyncStorage",0,C,"workUnitAsyncStorage",0,A],31501)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0swk7a6._.js.map