module.exports=[21979,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_pay_page_actions_0c.zae9.js.map