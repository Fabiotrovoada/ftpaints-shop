module.exports=[89912,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_basket_page_actions_0uh2yi0.js.map