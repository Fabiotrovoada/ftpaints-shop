module.exports=[2181,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_account_invoices_%5Bid%5D_pdf_route_actions_0-01xgn.js.map