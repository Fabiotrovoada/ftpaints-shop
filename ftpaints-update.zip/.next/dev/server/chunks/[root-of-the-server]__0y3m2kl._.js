module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/string_decoder [external] (string_decoder, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("string_decoder", () => require("string_decoder"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/odoo.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeKw",
    ()=>executeKw,
    "searchCount",
    ()=>searchCount,
    "searchRead",
    ()=>searchRead
]);
/**
 * Odoo XML-RPC client for FTPaints trade portal
 * Uses staging by default; switch URL/DB/PASS for live
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xmlrpc$2f$lib$2f$xmlrpc$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/xmlrpc/lib/xmlrpc.js [app-route] (ecmascript)");
;
const CONFIG = {
    url: process.env.ODOO_URL || 'https://ftpaints-staging-29116344.dev.odoo.com',
    db: process.env.ODOO_DB || 'ftpaints-staging-29116344',
    user: process.env.ODOO_USER || 'fabio@ftpaints.co.uk',
    pass: process.env.ODOO_PASS || 'admin'
};
function makeClient(path) {
    const url = new URL(CONFIG.url);
    const opts = {
        host: url.hostname,
        port: url.port ? parseInt(url.port) : 443,
        path,
        ssl: true
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xmlrpc$2f$lib$2f$xmlrpc$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].createSecureClient(opts);
}
let _uid = null;
async function methodCall(client, method, params) {
    return new Promise((resolve, reject)=>{
        client.methodCall(method, params, (err, val)=>{
            if (err) reject(err);
            else resolve(val);
        });
    });
}
async function getUid() {
    if (_uid) return _uid;
    const common = makeClient('/xmlrpc/2/common');
    const uid = await methodCall(common, 'authenticate', [
        CONFIG.db,
        CONFIG.user,
        CONFIG.pass,
        {}
    ]);
    if (!uid || uid === false) throw new Error('Odoo auth failed');
    _uid = uid;
    return _uid;
}
async function executeKw(model, method, args, kwargs = {}) {
    const uid = await getUid();
    const models = makeClient('/xmlrpc/2/object');
    return methodCall(models, 'execute_kw', [
        CONFIG.db,
        uid,
        CONFIG.pass,
        model,
        method,
        args,
        kwargs
    ]);
}
async function searchRead(model, domain, fields, opts = {}) {
    const result = await executeKw(model, 'search_read', [
        domain
    ], {
        fields,
        limit: opts.limit ?? 100,
        offset: opts.offset ?? 0,
        ...opts.order ? {
            order: opts.order
        } : {}
    });
    return result;
}
async function searchCount(model, domain) {
    const result = await executeKw(model, 'search_count', [
        domain
    ]);
    return result;
}
}),
"[project]/app/api/products/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$odoo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/odoo.ts [app-route] (ecmascript)");
;
;
async function GET(req) {
    try {
        const { searchParams } = new URL(req.url);
        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '24');
        const search = searchParams.get('search') || '';
        const category = searchParams.get('category') || '';
        const sort = searchParams.get('sort') || 'name asc';
        const offset = (page - 1) * limit;
        const domain = [
            [
                'sale_ok',
                '=',
                true
            ],
            [
                'active',
                '=',
                true
            ]
        ];
        if (search) domain.push([
            'name',
            'ilike',
            search
        ]);
        if (category) domain.push([
            'categ_id',
            '=',
            parseInt(category)
        ]);
        const [products, total] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$odoo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["searchRead"])('product.template', domain, [
                'id',
                'name',
                'default_code',
                'list_price',
                'categ_id',
                'description_sale',
                'qty_available',
                'virtual_available',
                'uom_id',
                'product_variant_count'
            ], {
                limit,
                offset,
                order: sort
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$odoo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["searchCount"])('product.template', domain)
        ]);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            products,
            total,
            page,
            limit
        });
    } catch (e) {
        console.error('products API error:', e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: e.message
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0y3m2kl._.js.map